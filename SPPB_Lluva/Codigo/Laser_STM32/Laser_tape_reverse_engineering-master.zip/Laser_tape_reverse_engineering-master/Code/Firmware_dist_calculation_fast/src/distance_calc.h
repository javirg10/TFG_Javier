#include "stm32f10x.h"

#ifndef _DISTANCE_CALC_H
#define _DISTANCE_CALC_H


int32_t triple_dist_calculaton(int16_t phase1, int16_t phase2, int16_t phase3);

#endif
