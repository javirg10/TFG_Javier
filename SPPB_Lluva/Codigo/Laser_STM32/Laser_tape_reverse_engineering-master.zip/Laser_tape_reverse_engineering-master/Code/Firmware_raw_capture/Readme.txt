Firmware for "x-40" laser tape
By ILIASAM
This program configures PLL and other tape peripherals
After receiving "M" symbol, program start capturing data from two ADC channels
After capture is done, program send data to the PC
UART baudrate - 256000