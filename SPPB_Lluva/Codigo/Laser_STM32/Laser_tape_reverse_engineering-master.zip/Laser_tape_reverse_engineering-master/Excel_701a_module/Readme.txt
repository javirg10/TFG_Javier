"amplitude_b" - dependence signal amplitude (at 193.5 MHz) from APD temperature and voltage.  
"phase" dependence signal phase (A - 25MHz and B - 193.5 MHz) from APD temperature and voltage.  