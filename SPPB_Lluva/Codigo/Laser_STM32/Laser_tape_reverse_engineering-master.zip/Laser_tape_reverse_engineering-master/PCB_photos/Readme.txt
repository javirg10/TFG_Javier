These are photos of two laser tape boards - big and small.
Also there is some picture of PCB that I found in Internet store. I modified this picture - added component designators and better wire traces.
