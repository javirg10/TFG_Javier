Results of the capturing and analyze laser tape I2C bus (with original firmware).
"file1" - start and single measurement of laser tape.