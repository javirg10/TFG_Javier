"PC_raw_capture" - PC utility to be used with "Firmware_raw_capture".  
Allows to view data captured by ADC; calculate FFT and calculate phase difference using Goertzel algorithm.  
Set "Auto Request" checkbox to get data from module.  
![Alt text](Screenshot1.png?raw=true "Image")  

"PC_phase_analyse" - PC utility to be used with "Firmware_phase_calculation".  
Allows to view phase values of three signals; calculate distance to the object.  
![Alt text](Screenshot2.png?raw=true "Image") 

"PC_show_results" - PC utility to be used with "Firmware_dist_calculation_simple" and "Firmware_dist_calculation_fast".  
Allows to view distance and another parameters send by rangefinder module.  
![Alt text](Screenshot3.png?raw=true "Image")
